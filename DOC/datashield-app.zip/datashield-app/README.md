# DataShield India — Competitive Intelligence & Architecture

A Vite + React single-page app (the same interface shown in the Claude artifact),
ready to deploy on Render.

## Deploy on Render

### Option A — Blueprint (one click, recommended)
1. Push this folder to a GitHub repo.
2. In Render: **New → Blueprint** → connect the repo. Render will read `render.yaml`
   and configure everything automatically.
3. Click **Apply** — Render builds and deploys.

### Option B — Manual Static Site
1. Push this folder to a GitHub repo.
2. In Render: **New → Static Site** → connect the repo.
3. Build command: `npm install && npm run build`
4. Publish directory: `dist`
5. Deploy.

### Option C — Manual Web Service
1. Push this folder to a GitHub repo.
2. In Render: **New → Web Service** → connect the repo, runtime **Node**.
3. Build command: `npm install && npm run build`
4. Start command: `npx serve -s dist -l $PORT`
5. Deploy.

## Local development
```bash
npm install
npm run dev
```

## Local production preview
```bash
npm run build
npm run preview
```
